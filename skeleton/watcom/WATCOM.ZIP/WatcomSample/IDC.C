#include <devtype.h>
#include <devhelp.h>
#include <devrp.h>

WORD32  GusIDC(void __far* );
#pragma aux (IDC) GusIDC "ULTRA_IDC";
WORD32  GusIDC(void __far* )
{
  return 0;
}
