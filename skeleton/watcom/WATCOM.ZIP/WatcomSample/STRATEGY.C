#include <devhelp.h>
#include <devtype.h>
#include <devrp.h>
#include "devown.h"

WORD32 StratIOCtl(RP __far *_rp);
WORD32 StratClose(RP __far *_rp);
WORD32 StratRemove(RP __far *_rp);

WORD32 StratSkIOCtl(RP __far *_rp);
WORD32 StratSkClose(RP __far *_rp);


// SvL: Needed in StratOpen
WORD32 deviceOwner = DEV_NO_OWNER; //UltiMOD, PCM, MIDI etc.
WORD32 numOS2Opens = 0;
// SvL: End

WORD32 StratOpen(RP __far*)
{
	if (numOS2Opens == 0) {
		deviceOwner = DEV_PDD_OWNER;
	}
	numOS2Opens++;
        return RPDONE;
}

#pragma off (unreferenced)
static WORD32 StratWrite(RP __far* _rp)
#pragma on (unreferenced)
{
  return RPDONE | RPERR;
}

extern WORD32 DiscardableInit(RPInit __far*);  

// External initialization entry-point
WORD32 StratInit(RP __far* _rp)
{
  RPInit __far* rp = (RPInit __far*)_rp;
  return DiscardableInit(rp);
}


// External initialization entry-point
#pragma off (unreferenced)
WORD32 StratInitComplete(RP __far* _rp)
#pragma on (unreferenced)
{
  return(RPDONE);
}

// Handle unsupported requests
static WORD32 StratError(RP __far*)
{
  return RPERR_COMMAND | RPDONE;
}


// Strategy dispatch table
//
// This table is used by the strategy routine to dispatch strategy requests

typedef WORD32 (*RPHandler)(RP __far* rp);
RPHandler StratDispatch[] =
{
  StratInit,                  // 00 (BC): Initialization
  StratError,                 // 01 (B ): Media check
  StratError,                 // 02 (B ): Build BIOS parameter block
  StratError,                 // 03 (  ): Unused
  StratError,                 // 04 (BC): Read
  StratError,                 // 05 ( C): Nondestructive read with no wait
  StratError,                 // 06 ( C): Input status
  StratError,                 // 07 ( C): Input flush
  StratWrite,                 // 08 (BC): Write
  StratError,                 // 09 (BC): Write verify
  StratError,                 // 0A ( C): Output status
  StratError,                 // 0B ( C): Output flush
  StratError,                 // 0C (  ): Unused
  StratOpen,                  // 0D (BC): Open
  StratClose,                 // 0E (BC): Close
  StratError,                 // 0F (B ): Removable media check
  StratIOCtl,                 // 10 (BC): IO Control
  StratError,                 // 11 (B ): Reset media
  StratError,                 // 12 (B ): Get logical unit
  StratError,                 // 13 (B ): Set logical unit
  StratError,                 // 14 ( C): Deinstall character device driver
  StratError,                 // 15 (  ): Unused
  StratError,                 // 16 (B ): Count partitionable fixed disks
  StratError,                 // 17 (B ): Get logical unit mapping of fixed disk
  StratError,                 // 18 (  ): Unused
  StratError,                 // 19 (  ): Unused
  StratError,                 // 1A (  ): Unused
  StratError,                 // 1B (  ): Unused
  StratError,                 // 1C (BC): Notify start or end of system shutdown
  StratError,                 // 1D (B ): Get driver capabilities
  StratError,                 // 1E (  ): Unused
  StratInitComplete           // 1F (BC): Notify end of initialization
};



// Strategy entry point
//
// The strategy entry point must be declared according to the STRATEGY
// calling convention, which fetches arguments from the correct registers.

WORD32 Strategy(RP __far* rp);
#pragma aux (STRATEGY) Strategy "ULTRA_STRATEGY";
WORD32 Strategy(RP __far* rp)
{
  if (rp->Command < sizeof(StratDispatch)/sizeof(StratDispatch[0]))
       	return(StratDispatch[rp->Command](rp));
  else	return(RPERR_COMMAND | RPDONE);
}



