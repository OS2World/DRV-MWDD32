#include <devhelp.h>
#include <devtype.h>
#include <devrp.h>
#include "devown.h"

//******************************************************************************
// Dispatch IOCtl requests received from the Strategy routine
//******************************************************************************
WORD32 StratIOCtl(RP __far* _rp)
{
  RPIOCtl __far* rp = (RPIOCtl __far*)_rp;

  return RPERR_COMMAND | RPDONE;
}
//******************************************************************************
// Dispatch Close requests received from the strategy routine
//******************************************************************************
WORD32 StratClose(RP __far* _rp)
{
  RPOpenClose __far* rp = (RPOpenClose __far*)_rp;

  // only called if device successfully opened
  numOS2Opens--;

  if (numOS2Opens == 0) {
	deviceOwner = DEV_NO_OWNER;
  }
  return(RPDONE);
}
