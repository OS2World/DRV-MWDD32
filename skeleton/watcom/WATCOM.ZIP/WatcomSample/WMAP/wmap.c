#define INCL_DOSFILEMGR
#include <os2.h>
#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <io.h>
#define TRUE 1
#define FALSE 0

// support procedure
int openmap(char *, int type);
int ConvertPublics();

char *modname;

int main(int argc, char *argv[])
{

 if(argc != 4) {
	printf("Syntax: wmap modulename infile.map outfile.map.\n");
	return(1);
 }
 modname = argv[1];

 if(!openmap(argv[2], TRUE)) {
	printf("Error opening mapfile.\n");
	return(1);
 }
 if(!openmap(argv[3], FALSE)) {
	printf("Error opening mapfile.\n");
	return(1);
 }
 if(!ConvertPublics()) printf("Error occurred while converting mapfile.\n");

 return(0);
}

// file handles
FILE *inmap;
FILE *outmap;
int Mapsize;

/******************************************************************************/
/******************************************************************************/
/******************************************************************************/
/******************************************************************************/
/******************************************************************************/

int openmap(char *infile, int type)
{
HFILE modin;
USHORT Action;
ULONG        FileInfoLevel;   /* Level of file info required */
FILESTATUS3  FileInfoBuf;     /* File info buffer */
ULONG        FileInfoBufSize; /* File data buffer size */
APIRET       rc;              /* Return code */

 if(type) {
	DosOpen(infile,     /* file name from Open dialog */
		  &modin,	      /* file handle returned */
		  &Action,
		  0L,
		  FILE_NORMAL,
		  FILE_OPEN,
		  OPEN_ACCESS_READONLY | OPEN_SHARE_DENYWRITE,
		  (PEAOP2)NULL);

        FileInfoLevel = 1;    /* Indicate that Level 1 information */
        FileInfoBufSize = sizeof(FILESTATUS3);
        rc = DosQueryFileInfo(modin, FileInfoLevel,
                              &FileInfoBuf, FileInfoBufSize);
        if (rc != 0) return FALSE;
        Mapsize = FileInfoBuf.cbFile;
	DosClose(modin);
	inmap = fopen(infile, "r");
	if(inmap == NULL) return FALSE;
 }
 else {
	outmap = fopen(infile, "w+");
	if(outmap == NULL) return FALSE;
 }
 return TRUE;
}

/******************************************************************************/
/******************************************************************************/
/******************************************************************************/
/******************************************************************************/
/******************************************************************************/
int ConvertPublics()
{ 
 char mapline[256];	//regel uit mapfile
 char segname[32];
 char classname[32], groupname[32];
 char dummy;
 char varname[256];
 char cppvarname[256];
 char *variable;
 char bits16[] = "16-bit";
 char bits32[] = "32-bit";
 char *bits = bits16;
 int segment, offset, size, i;
 
 fprintf(outmap, "\n %s\n\n Start         Length     Name                   Class\n\n", modname);

 while(TRUE) {
	 if(fgets(mapline, sizeof(mapline), inmap) == NULL)	return(FALSE);
 
	 if(strstr(mapline , "Segments") != NULL)	break;
 }
 //skip two lines
 fgets(mapline, sizeof(mapline), inmap);
 fgets(mapline, sizeof(mapline), inmap);
 //skip : Segment                Class          Group          Address         Size
 fgets(mapline, sizeof(mapline), inmap);
 //skip : =======                =====          =====          =======         ====
 fgets(mapline, sizeof(mapline), inmap);
 //skip empty line
 fgets(mapline, sizeof(mapline), inmap);
 //get first segment line
 fgets(mapline, sizeof(mapline), inmap);
 i = 0;
 while(mapline[0] != 0xA && mapline[1] != 0xD) {
	if(mapline[38] != 0x20) {
		sscanf(mapline, "%22s %14s %14s %4X:%8X   %8X", segname, classname, 
		       groupname, &segment, &offset, &size);
	}
	else {
		sscanf(mapline, "%22s %14s                %4X:%8X   %8X", segname, classname, 
		       &segment, &offset, &size);
	}
//C_COMMON               DATA           DGROUP         0004:00000000   00000000
	sprintf(mapline, " %04X:%08X %09XH %-22s %s %s\n", segment, offset, size,
		segname, classname, bits);
	fprintf(outmap, "%s\n", mapline);

	fgets(mapline, sizeof(mapline), inmap);
	if(++i == 2)	bits = bits32;
 }

 fprintf(outmap, "\n Origin   Group\n\n 0000:0   FLAT\n 0004:0   DGROUP\n\n");
 fprintf(outmap, "  Address         Publics by Name\n\n\n\n  Address         Publics by Value\n\n");

 while(TRUE) {
	 if(fgets(mapline, sizeof(mapline), inmap) == NULL)	return(FALSE);
 
	 if(strstr(mapline , "Address        Symbol") != NULL)	break;
 }
 //skip two lines
 fgets(mapline, sizeof(mapline), inmap);
 fgets(mapline, sizeof(mapline), inmap);

 //get first memory map line
 fgets(mapline, sizeof(mapline), inmap);
 while(mapline[0] != 0xA && mapline[1] != 0xD) {
	sscanf(mapline, "%4X:%8X%c %s", &segment, &offset, &dummy, &varname);
//0003:0000016c  W?IwavePnpKey$n()v
	if((variable = strstr(varname, "W?")) != NULL) {
		variable += 2;
		//demangle name
		for(i=0;i<strlen(variable);i++) {
			if(variable[i] == '$') {
				variable[i] = 0;
				break;
			}
		}		
	}
	else	variable = varname;	
	sprintf(mapline, " %04X:%08X       %-22s\n", segment, offset, variable);
	fprintf(outmap, "%s", mapline);
// 0001:00000000       device_header

	fgets(mapline, sizeof(mapline), inmap);
 }

 fclose(inmap);
 fclose(outmap);
 return(TRUE);
}