// Device support
#include <devhelp.h>
#include <devtype.h>
#include <devrp.h>
#include "devown.h"


static char ERR_ERROR[] = "ERROR: ";
static char ERR_LOCK[]  = "Unable to lock 32 bit data & code segments, exiting...\r\r\n";
static char ERR_SIGN[]  = "32 Bits Example Device Driver compiled with Watcom C/C++\r\n";
static char ERR_COPY1[] = "Copyright (1996-1997) Matthieu Willm\r\n";
static char ERR_COPY2[] = "Copyright (1996-1997) Sander van Leeuwen\r\n";

typedef struct {
 USHORT MsgLength;
 WORD32 MsgPtr;
} MSG_TABLE;

extern "C" WORD32 MSG_TABLE32;

//Print messages with DosWrite when init is done or has failed (see startup.asm)
void DevSaveMessage(char __far *str, int length)
{
 MSG_TABLE __far *msg = (MSG_TABLE __far *)__Make48Pointer(MSG_TABLE32);
 char __far *str16 = (char __far *)__Make48Pointer(msg->MsgPtr);
 int i;

  for(i=0;i<length;i++) {
	str16[msg->MsgLength + i] = str[i];
  }
  str16[msg->MsgLength + length] = 0;
  msg->MsgLength += length;

  return;
}

//SvL: Lock our 32 bits data & code segments
int LockSegments(void) 
{
 ULONG  PgCount;
 char   lock[12];

    /*
     * Locks DGROUP into physical memory
     */
    if(DevVMLock(VMDHL_LONG | VMDHL_WRITE | VMDHL_VERIFY,
                   (long)OffsetBeginDS32,
                   (ULONG)(OffsetFinalDS32 - OffsetBeginDS32),
                   (void *)-1,
                   __StackToFlat((void *)lock),
                   (unsigned long *)__StackToFlat((void *)&PgCount))) {
	return(1);
    }
    /*
     * Locks CODE32 into physical memory
     */
    if(DevVMLock(VMDHL_LONG | VMDHL_VERIFY,
                  (long)OffsetBeginCS32,
                  (ULONG)(OffsetFinalCS32 - OffsetBeginCS32),
                  (void *)-1,
                  __StackToFlat((void *)lock),
                  (unsigned long *)__StackToFlat((void *)&PgCount))) {
	return(1);
    }
    return 0;
}


// Write a string of specified length
static VOID WriteString(const char __far* str, int length)
{
  // Write the string
  DevSaveMessage((char __far *)str, length);
  return;
}

// Initialize device driver

WORD32 DiscardableInit(RPInit __far* rp)  
{

  GetTKSSBase();
  if(LockSegments()) {
    WriteString(ERR_ERROR, sizeof(ERR_ERROR)-1);
    WriteString(ERR_LOCK, sizeof(ERR_LOCK)-1);
    return RPDONE | RPERR;
  }

  rp->Out.FinalCS = 0;
  rp->Out.FinalDS = 0;

  //Do you init here:

  WriteString(ERR_SIGN, sizeof(ERR_SIGN)-1);
  WriteString(ERR_COPY1, sizeof(ERR_COPY1)-1);
  WriteString(ERR_COPY2, sizeof(ERR_COPY2)-1);

  // Complete the installation
  rp->Out.FinalCS = _OffsetFinalCS16;
  rp->Out.FinalDS = _OffsetFinalDS16;

  // Confirm a successful installation
  return RPDONE;
}




